import { Link } from 'react-router';
import { Heart, Eye } from 'lucide-react';
import type { Pet } from '../data/pets';

interface PetCardProps {
  pet: Pet;
}

export function PetCard({ pet }: PetCardProps) {
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <Link to={`/pet/${pet.id}`}>
        <div className="aspect-square overflow-hidden bg-gray-100">
          <img
            src={pet.image}
            alt={pet.name}
            className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
          />
        </div>
      </Link>
      
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <div>
            <Link to={`/pet/${pet.id}`} className="hover:underline">
              <h3 className="font-semibold text-lg">{pet.name}</h3>
            </Link>
            <p className="text-sm text-gray-600">{pet.breed} • {pet.age} yr</p>
          </div>
          <button className="text-pink-500 hover:text-pink-600 transition-colors">
            <Heart className="size-5" />
          </button>
        </div>
        
        <div className="flex flex-wrap gap-1 mb-3">
          {pet.tags.map((tag) => (
            <span
              key={tag}
              className="px-2 py-1 bg-pink-50 text-pink-600 text-xs rounded-full"
            >
              #{tag}
            </span>
          ))}
        </div>

        <Link to={`/pet/${pet.id}`}>
          <button className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition-colors">
            <Eye className="size-4" />
            View Profile
          </button>
        </Link>
      </div>
    </div>
  );
}
