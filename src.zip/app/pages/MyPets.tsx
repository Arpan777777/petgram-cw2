import { PetCard } from '../components/PetCard';
import { pets } from '../data/pets';

export default function MyPets() {
  // Mock: showing first 3 pets as "user's pets"
  const myPets = pets.slice(0, 3);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">My Pets</h1>
          <p className="text-gray-600">Manage and view your pet profiles</p>
        </div>

        {myPets.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {myPets.map((pet) => (
              <PetCard key={pet.id} pet={pet} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-white rounded-lg">
            <p className="text-gray-500 mb-4">You haven't added any pets yet</p>
            <button className="px-6 py-3 bg-pink-500 text-white rounded-lg hover:bg-pink-600 transition-colors">
              Add Your First Pet
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
